<?php
/**
 * Email Mailer Class using PHPMailer
 * Untuk mengirim OTP via SMTP Gmail
 */

require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class Mailer {
    private $mail;
    private $config;
    
    public function __construct() {
        $this->config = require __DIR__ . '/../config/smtp.php';
        $this->mail = new PHPMailer(true);
        $this->setupSMTP();
    }
    
    private function setupSMTP() {
        try {
            $this->mail->isSMTP();
            $this->mail->Host = $this->config['host'];
            $this->mail->SMTPAuth = true;
            $this->mail->Username = $this->config['username'];
            $this->mail->Password = $this->config['password'];
            $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $this->mail->Port = $this->config['port'];
            $this->mail->SMTPDebug = $this->config['debug'];
            
            $this->mail->setFrom($this->config['from_email'], $this->config['from_name']);
            $this->mail->CharSet = 'UTF-8';
        } catch (Exception $e) {
            error_log("Mailer setup error: " . $e->getMessage());
        }
    }
    
    public function sendOTP($toEmail, $toName, $otpCode) {
        try {
            $this->mail->clearAddresses();
            $this->mail->addAddress($toEmail, $toName);
            
            $this->mail->isHTML(true);
            $this->mail->Subject = 'Kode OTP Verifikasi - HRMS';
            
            $body = $this->getOTPEmailTemplate($toName, $otpCode);
            $this->mail->Body = $body;
            $this->mail->AltBody = "Kode OTP Anda adalah: $otpCode. Kode ini berlaku selama 30 menit.";
            
            $this->mail->send();
            return ['success' => true, 'message' => 'OTP berhasil dikirim ke ' . $toEmail];
        } catch (Exception $e) {
            error_log("Mailer send error: " . $this->mail->ErrorInfo);
            return ['success' => false, 'message' => 'Gagal mengirim email: ' . $this->mail->ErrorInfo];
        }
    }
    
    private function getOTPEmailTemplate($name, $otp) {
        $otpDigits = str_split($otp);
        $otpBoxes = '';
        foreach ($otpDigits as $digit) {
            $otpBoxes .= "<span style='display:inline-block;width:45px;height:55px;background:#f8f9fa;border:2px solid #0d6efd;border-radius:8px;font-size:28px;font-weight:bold;color:#0d6efd;text-align:center;line-height:55px;margin:0 3px;'>$digit</span>";
        }
        
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        </head>
        <body style='margin:0;padding:0;font-family:Arial,sans-serif;background-color:#f5f5f5;'>
            <div style='max-width:600px;margin:20px auto;background:#ffffff;border-radius:12px;box-shadow:0 4px 6px rgba(0,0,0,0.1);overflow:hidden;'>
                <div style='background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);padding:30px;text-align:center;'>
                    <h1 style='color:#ffffff;margin:0;font-size:28px;'>🔐 HRMS</h1>
                    <p style='color:rgba(255,255,255,0.9);margin:10px 0 0 0;font-size:14px;'>Human Resources Management System</p>
                </div>
                
                <div style='padding:40px 30px;text-align:center;'>
                    <h2 style='color:#333;margin:0 0 10px 0;font-size:22px;'>Verifikasi Login Anda</h2>
                    <p style='color:#666;margin:0 0 30px 0;font-size:15px;'>Halo <strong>$name</strong>, gunakan kode OTP berikut untuk melanjutkan login:</p>
                    
                    <div style='margin:30px 0;'>
                        $otpBoxes
                    </div>
                    
                    <div style='background:#fff3cd;border:1px solid #ffc107;border-radius:8px;padding:15px;margin:25px 0;'>
                        <p style='color:#856404;margin:0;font-size:13px;'>
                            ⏱️ Kode ini berlaku selama <strong>30 menit</strong>.<br>
                            Jangan bagikan kode ini kepada siapapun!
                        </p>
                    </div>
                    
                    <p style='color:#999;font-size:12px;margin:20px 0 0 0;'>
                        Jika Anda tidak meminta kode ini, abaikan email ini.
                    </p>
                </div>
                
                <div style='background:#f8f9fa;padding:20px;text-align:center;border-top:1px solid #eee;'>
                    <p style='color:#999;margin:0;font-size:12px;'>
                        &copy; " . date('Y') . " HRMS - Human Resources Management System
                    </p>
                </div>
            </div>
        </body>
        </html>";
    }
    
    public function isConfigured() {
        return !empty($this->config['password']);
    }
}
