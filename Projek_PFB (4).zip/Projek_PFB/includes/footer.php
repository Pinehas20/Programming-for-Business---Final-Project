    </main>
    <footer class="bg-light py-3 mt-auto">
        <div class="container text-center text-muted">
            <small>&copy; <?php echo date('Y'); ?> Sistem Manajemen Lembur. All rights reserved.</small>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app.js"></script>
</body>
</html>
