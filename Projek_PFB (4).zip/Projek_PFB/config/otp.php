<?php


return [
    'length' => 6,          
    'expiry' => 30,          
    'max_attempts' => 5,    
    'resend_cooldown' => 60  
];
