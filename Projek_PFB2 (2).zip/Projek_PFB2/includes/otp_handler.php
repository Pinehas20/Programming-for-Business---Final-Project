<?php
/**
 * OTP Handler Class
 * Mengelola pembuatan, verifikasi, dan validasi OTP
 */

require_once __DIR__ . '/../config/database.php';

class OTPHandler {
    private $conn;
    private $config;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
        $this->config = require __DIR__ . '/../config/otp.php';
    }
    
    public function generateOTP() {
        $length = $this->config['length'];
        $otp = '';
        for ($i = 0; $i < $length; $i++) {
            $otp .= mt_rand(0, 9);
        }
        return $otp;
    }
    
    public function createOTP($userId, $email) {
        $this->invalidatePreviousOTPs($userId);
        
        $otp = $this->generateOTP();
        $now = date('Y-m-d H:i:s');
        $expiresAt = date('Y-m-d H:i:s', strtotime('+' . $this->config['expiry'] . ' minutes'));
        
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO otp_codes (user_id, email, otp_code, expires_at, attempts, is_used, created_at)
                VALUES (:user_id, :email, :otp_code, :expires_at, 0, 0, :created_at)
            ");
            $stmt->execute([
                ':user_id' => $userId,
                ':email' => $email,
                ':otp_code' => password_hash($otp, PASSWORD_DEFAULT),
                ':expires_at' => $expiresAt,
                ':created_at' => $now
            ]);
            
            return ['success' => true, 'otp' => $otp, 'expires_at' => $expiresAt];
        } catch (PDOException $e) {
            error_log("OTP creation error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Gagal membuat OTP'];
        }
    }
    
    public function verifyOTP($userId, $inputOtp) {
        try {
            $now = date('Y-m-d H:i:s');
            $stmt = $this->conn->prepare("
                SELECT * FROM otp_codes 
                WHERE user_id = :user_id 
                AND is_used = 0 
                AND expires_at > :now
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $stmt->execute([':user_id' => $userId, ':now' => $now]);
            $otpRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$otpRecord) {
                return ['success' => false, 'message' => 'OTP tidak ditemukan atau sudah kedaluwarsa'];
            }
            
            if ($otpRecord['attempts'] >= $this->config['max_attempts']) {
                $this->markOTPAsUsed($otpRecord['id']);
                return ['success' => false, 'message' => 'Terlalu banyak percobaan. Silakan minta OTP baru.'];
            }
            
            if (password_verify($inputOtp, $otpRecord['otp_code'])) {
                $this->markOTPAsUsed($otpRecord['id']);
                return ['success' => true, 'message' => 'OTP valid'];
            } else {
                $this->incrementAttempts($otpRecord['id']);
                $remaining = $this->config['max_attempts'] - ($otpRecord['attempts'] + 1);
                return ['success' => false, 'message' => "OTP salah. Sisa percobaan: $remaining"];
            }
        } catch (PDOException $e) {
            error_log("OTP verification error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Terjadi kesalahan saat verifikasi'];
        }
    }
    
    private function invalidatePreviousOTPs($userId) {
        try {
            $stmt = $this->conn->prepare("UPDATE otp_codes SET is_used = 1 WHERE user_id = :user_id AND is_used = 0");
            $stmt->execute([':user_id' => $userId]);
        } catch (PDOException $e) {
            error_log("OTP invalidation error: " . $e->getMessage());
        }
    }
    
    private function markOTPAsUsed($otpId) {
        try {
            $stmt = $this->conn->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = :id");
            $stmt->execute([':id' => $otpId]);
        } catch (PDOException $e) {
            error_log("OTP mark used error: " . $e->getMessage());
        }
    }
    
    private function incrementAttempts($otpId) {
        try {
            $stmt = $this->conn->prepare("UPDATE otp_codes SET attempts = attempts + 1 WHERE id = :id");
            $stmt->execute([':id' => $otpId]);
        } catch (PDOException $e) {
            error_log("OTP increment attempts error: " . $e->getMessage());
        }
    }
    
    public function canResendOTP($userId) {
        try {
            $stmt = $this->conn->prepare("
                SELECT created_at FROM otp_codes 
                WHERE user_id = :user_id 
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $stmt->execute([':user_id' => $userId]);
            $lastOtp = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$lastOtp) {
                return ['can_resend' => true];
            }
            
            $lastSent = strtotime($lastOtp['created_at']);
            $cooldown = $this->config['resend_cooldown'];
            $nextResend = $lastSent + $cooldown;
            $now = time();
            
            if ($now >= $nextResend) {
                return ['can_resend' => true];
            } else {
                return ['can_resend' => false, 'wait_seconds' => $nextResend - $now];
            }
        } catch (PDOException $e) {
            error_log("OTP resend check error: " . $e->getMessage());
            return ['can_resend' => true];
        }
    }
    
    public function getActiveOTPExpiry($userId) {
        try {
            $now = date('Y-m-d H:i:s');
            $stmt = $this->conn->prepare("
                SELECT expires_at FROM otp_codes 
                WHERE user_id = :user_id 
                AND is_used = 0 
                AND expires_at > :now
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $stmt->execute([':user_id' => $userId, ':now' => $now]);
            $otp = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $otp ? $otp['expires_at'] : null;
        } catch (PDOException $e) {
            return null;
        }
    }
}
