<?php
$pageTitle = 'Kelola Cuti';
require_once 'includes/header.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $leaveId = intval($_POST['leave_id']);
    $action = $_POST['action'];
    
    if ($action === 'approve' || $action === 'reject') {
        $status = $action === 'approve' ? 'approved' : 'rejected';
        try {
            $stmt = $conn->prepare("UPDATE leave_requests SET status = :status, approved_by = :admin_id, updated_at = NOW() WHERE id = :id");
            $stmt->execute([
                ':status' => $status,
                ':admin_id' => $_SESSION['user_id'],
                ':id' => $leaveId
            ]);
            
            $leaveData = $conn->prepare("SELECT lr.*, u.full_name FROM leave_requests lr JOIN users u ON lr.employee_id = u.id WHERE lr.id = :id");
            $leaveData->execute([':id' => $leaveId]);
            $leave = $leaveData->fetch();
            
            $msgSubject = $action === 'approve' ? 'Pengajuan Cuti Disetujui' : 'Pengajuan Cuti Ditolak';
            $msgContent = $action === 'approve' 
                ? "Pengajuan cuti Anda untuk tanggal " . date('d/m/Y', strtotime($leave['start_date'])) . " - " . date('d/m/Y', strtotime($leave['end_date'])) . " telah disetujui."
                : "Mohon maaf, pengajuan cuti Anda untuk tanggal " . date('d/m/Y', strtotime($leave['start_date'])) . " - " . date('d/m/Y', strtotime($leave['end_date'])) . " tidak dapat disetujui.";
            
            $insertMsg = $conn->prepare("INSERT INTO inbox (recipient_id, sender_id, sender_name, subject, message, message_type) VALUES (:recipient, :sender, 'HR Admin', :subject, :message, 'info')");
            $insertMsg->execute([
                ':recipient' => $leave['employee_id'],
                ':sender' => $_SESSION['user_id'],
                ':subject' => $msgSubject,
                ':message' => $msgContent
            ]);
            
            $success = $action === 'approve' ? 'Pengajuan cuti berhasil disetujui!' : 'Pengajuan cuti ditolak.';
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

$filter = $_GET['filter'] ?? 'pending';
$filterSql = $filter === 'all' ? '' : "WHERE lr.status = :status";

$query = "SELECT lr.*, u.full_name, u.department, u.position,
          (SELECT full_name FROM users WHERE id = lr.approved_by) as approved_by_name
          FROM leave_requests lr 
          JOIN users u ON lr.employee_id = u.id 
          $filterSql
          ORDER BY lr.created_at DESC";

$stmt = $conn->prepare($query);
if ($filter !== 'all') {
    $stmt->execute([':status' => $filter]);
} else {
    $stmt->execute();
}
$leaves = $stmt->fetchAll();

$leaveTypes = [
    'annual' => 'Cuti Tahunan',
    'sick' => 'Cuti Sakit',
    'personal' => 'Cuti Pribadi',
    'maternity' => 'Cuti Melahirkan',
    'paternity' => 'Cuti Ayah',
    'unpaid' => 'Cuti Tanpa Gaji'
];
?>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <ul class="nav nav-tabs card-header-tabs">
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'pending' ? 'active' : ''; ?>" href="?filter=pending">
                    Menunggu Persetujuan
                    <?php if ($pendingLeave > 0): ?>
                        <span class="badge bg-danger"><?php echo $pendingLeave; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'approved' ? 'active' : ''; ?>" href="?filter=approved">Disetujui</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'rejected' ? 'active' : ''; ?>" href="?filter=rejected">Ditolak</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'all' ? 'active' : ''; ?>" href="?filter=all">Semua</a>
            </li>
        </ul>
    </div>
    <div class="card-body p-0">
        <?php if (empty($leaves)): ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">Tidak ada data pengajuan cuti</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Karyawan</th>
                            <th>Tipe Cuti</th>
                            <th>Tanggal</th>
                            <th>Durasi</th>
                            <th>Alasan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($leaves as $leave): 
                            $startDate = new DateTime($leave['start_date']);
                            $endDate = new DateTime($leave['end_date']);
                            $duration = $startDate->diff($endDate)->days + 1;
                        ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($leave['full_name']); ?></strong>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($leave['department']); ?> - <?php echo htmlspecialchars($leave['position']); ?></small>
                                </td>
                                <td><?php echo $leaveTypes[$leave['leave_type']] ?? ucfirst($leave['leave_type']); ?></td>
                                <td>
                                    <?php echo date('d/m/Y', strtotime($leave['start_date'])); ?>
                                    <?php if ($leave['start_date'] !== $leave['end_date']): ?>
                                        <br><small class="text-muted">s/d <?php echo date('d/m/Y', strtotime($leave['end_date'])); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $duration; ?> hari</td>
                                <td><small><?php echo htmlspecialchars(substr($leave['reason'], 0, 50)); ?><?php echo strlen($leave['reason']) > 50 ? '...' : ''; ?></small></td>
                                <td>
                                    <?php
                                    $badgeClass = match($leave['status']) {
                                        'approved' => 'bg-success',
                                        'rejected' => 'bg-danger',
                                        default => 'bg-warning'
                                    };
                                    $statusText = match($leave['status']) {
                                        'approved' => 'Disetujui',
                                        'rejected' => 'Ditolak',
                                        default => 'Pending'
                                    };
                                    ?>
                                    <span class="badge <?php echo $badgeClass; ?>"><?php echo $statusText; ?></span>
                                    <?php if ($leave['approved_by_name']): ?>
                                        <br><small class="text-muted">oleh <?php echo htmlspecialchars($leave['approved_by_name']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($leave['status'] === 'pending'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="leave_id" value="<?php echo $leave['id']; ?>">
                                            <button type="submit" name="action" value="approve" class="btn btn-sm btn-success btn-approve">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                            <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger btn-reject">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
