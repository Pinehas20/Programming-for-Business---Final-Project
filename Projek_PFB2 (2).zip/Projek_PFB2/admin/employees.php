<?php
$pageTitle = 'Data Karyawan';
require_once 'includes/header.php';

$currentMonth = date('n');
$currentYear = date('Y');
$monthStart = date('Y-m-01');
$monthEnd = date('Y-m-t');
$yearStart = date('Y-01-01');
$yearEnd = date('Y-12-31');

$employees = $conn->query("
    SELECT u.*, 
           (SELECT COUNT(*) FROM attendance a WHERE a.employee_id = u.id AND a.date >= '$monthStart' AND a.date <= '$monthEnd') as attendance_count,
           (SELECT COUNT(*) FROM leave_requests lr WHERE lr.employee_id = u.id AND lr.status = 'approved' AND lr.start_date >= '$yearStart' AND lr.start_date <= '$yearEnd') as leave_count
    FROM users u 
    WHERE u.role = 'employee' OR u.role IS NULL OR u.role = ''
    ORDER BY u.full_name
")->fetchAll();
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-people me-2"></i>Daftar Karyawan</h5>
        <span class="badge bg-primary"><?php echo count($employees); ?> Karyawan</span>
    </div>
    <div class="card-body p-0">
        <?php if (empty($employees)): ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">Tidak ada data karyawan</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Departemen</th>
                            <th>Jabatan</th>
                            <th>Gaji Pokok</th>
                            <th>Kehadiran</th>
                            <th>Cuti Terpakai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($employees as $emp): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($emp['full_name']); ?></strong>
                                    <?php if ($emp['email']): ?>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($emp['email']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo htmlspecialchars($emp['username']); ?></code></td>
                                <td><?php echo htmlspecialchars($emp['department']); ?></td>
                                <td><?php echo htmlspecialchars($emp['position']); ?></td>
                                <td>Rp <?php echo number_format($emp['salary'], 0, ',', '.'); ?></td>
                                <td>
                                    <span class="badge bg-info"><?php echo $emp['attendance_count']; ?> hari</span>
                                    <small class="text-muted d-block">bulan ini</small>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo $emp['leave_count']; ?> hari</span>
                                    <small class="text-muted d-block">tahun ini</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
