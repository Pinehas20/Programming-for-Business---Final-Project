<?php
$pageTitle = 'Kelola Lembur';
require_once 'includes/header.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $overtimeId = intval($_POST['overtime_id']);
    $action = $_POST['action'];
    
    if ($action === 'approve' || $action === 'reject') {
        $status = $action === 'approve' ? 'approved' : 'rejected';
        try {
            $stmt = $conn->prepare("UPDATE overtime SET status = :status, approved_by = :admin_id, updated_at = NOW() WHERE id = :id");
            $stmt->execute([
                ':status' => $status,
                ':admin_id' => $_SESSION['user_id'],
                ':id' => $overtimeId
            ]);
            
            $otData = $conn->prepare("SELECT o.*, u.full_name FROM overtime o JOIN users u ON o.employee_id = u.id WHERE o.id = :id");
            $otData->execute([':id' => $overtimeId]);
            $ot = $otData->fetch();
            
            $msgSubject = $action === 'approve' ? 'Pengajuan Lembur Disetujui' : 'Pengajuan Lembur Ditolak';
            $msgContent = $action === 'approve' 
                ? "Pengajuan lembur Anda pada tanggal " . date('d/m/Y', strtotime($ot['date'])) . " selama " . $ot['duration'] . " jam telah disetujui."
                : "Mohon maaf, pengajuan lembur Anda pada tanggal " . date('d/m/Y', strtotime($ot['date'])) . " tidak dapat disetujui.";
            
            $insertMsg = $conn->prepare("INSERT INTO inbox (recipient_id, sender_id, sender_name, subject, message, message_type) VALUES (:recipient, :sender, 'HR Admin', :subject, :message, 'info')");
            $insertMsg->execute([
                ':recipient' => $ot['employee_id'],
                ':sender' => $_SESSION['user_id'],
                ':subject' => $msgSubject,
                ':message' => $msgContent
            ]);
            
            $success = $action === 'approve' ? 'Pengajuan lembur berhasil disetujui!' : 'Pengajuan lembur ditolak.';
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

$filter = $_GET['filter'] ?? 'pending';
$filterSql = $filter === 'all' ? '' : "WHERE o.status = :status";

$query = "SELECT o.*, u.full_name, u.department, u.position,
          (SELECT full_name FROM users WHERE id = o.approved_by) as approved_by_name
          FROM overtime o 
          JOIN users u ON o.employee_id = u.id 
          $filterSql
          ORDER BY o.created_at DESC";

$stmt = $conn->prepare($query);
if ($filter !== 'all') {
    $stmt->execute([':status' => $filter]);
} else {
    $stmt->execute();
}
$overtimes = $stmt->fetchAll();
?>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <ul class="nav nav-tabs card-header-tabs">
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'pending' ? 'active' : ''; ?>" href="?filter=pending">
                    Menunggu Persetujuan
                    <?php if ($pendingOvertime > 0): ?>
                        <span class="badge bg-danger"><?php echo $pendingOvertime; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'approved' ? 'active' : ''; ?>" href="?filter=approved">Disetujui</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'rejected' ? 'active' : ''; ?>" href="?filter=rejected">Ditolak</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo $filter === 'all' ? 'active' : ''; ?>" href="?filter=all">Semua</a>
            </li>
        </ul>
    </div>
    <div class="card-body p-0">
        <?php if (empty($overtimes)): ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">Tidak ada data pengajuan lembur</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Karyawan</th>
                            <th>Tanggal</th>
                            <th>Waktu</th>
                            <th>Durasi</th>
                            <th>Alasan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($overtimes as $ot): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($ot['full_name']); ?></strong>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($ot['department']); ?></small>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($ot['date'])); ?></td>
                                <td>
                                    <?php echo date('H:i', strtotime($ot['start_time'])); ?> - <?php echo date('H:i', strtotime($ot['end_time'])); ?>
                                </td>
                                <td><span class="badge bg-info"><?php echo $ot['duration']; ?> jam</span></td>
                                <td><small><?php echo htmlspecialchars(substr($ot['reason'], 0, 50)); ?><?php echo strlen($ot['reason']) > 50 ? '...' : ''; ?></small></td>
                                <td>
                                    <?php
                                    $badgeClass = match($ot['status']) {
                                        'approved' => 'bg-success',
                                        'rejected' => 'bg-danger',
                                        default => 'bg-warning'
                                    };
                                    $statusText = match($ot['status']) {
                                        'approved' => 'Disetujui',
                                        'rejected' => 'Ditolak',
                                        default => 'Pending'
                                    };
                                    ?>
                                    <span class="badge <?php echo $badgeClass; ?>"><?php echo $statusText; ?></span>
                                    <?php if ($ot['approved_by_name']): ?>
                                        <br><small class="text-muted">oleh <?php echo htmlspecialchars($ot['approved_by_name']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($ot['status'] === 'pending'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="overtime_id" value="<?php echo $ot['id']; ?>">
                                            <button type="submit" name="action" value="approve" class="btn btn-sm btn-success btn-approve">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                            <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger btn-reject">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
