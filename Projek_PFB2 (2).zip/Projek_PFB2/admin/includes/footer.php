                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.btn-approve, .btn-reject').forEach(btn => {
            btn.addEventListener('click', function(e) {
                const action = this.classList.contains('btn-approve') ? 'menyetujui' : 'menolak';
                if (!confirm(`Apakah Anda yakin ingin ${action} pengajuan ini?`)) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
