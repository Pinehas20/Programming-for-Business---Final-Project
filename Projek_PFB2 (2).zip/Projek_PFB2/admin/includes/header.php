<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../../config/database.php';

$database = new Database();
$conn = $database->getConnection();

try {
    $pendingLeave = $conn->query("SELECT COUNT(*) as count FROM leave_requests WHERE status = 'pending'")->fetch()['count'];
    $pendingOvertime = $conn->query("SELECT COUNT(*) as count FROM overtime WHERE status = 'pending'")->fetch()['count'];
    $totalEmployees = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'employee' OR role IS NULL OR role = ''")->fetch()['count'];
} catch (PDOException $e) {
    $pendingLeave = 0;
    $pendingOvertime = 0;
    $totalEmployees = 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Admin Panel'; ?> - HRMS Admin</title>
    <link rel="icon" type="image/png" href="../images/logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <style>
        .admin-sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
        }
        .admin-sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 4px 10px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover,
        .admin-sidebar .nav-link.active {
            color: #fff;
            background: rgba(255,255,255,0.1);
        }
        .admin-sidebar .nav-link i {
            width: 24px;
        }
        .admin-content {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-header {
            background: #fff;
            border-bottom: 1px solid #e9ecef;
            padding: 15px 25px;
        }
        .stat-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        .stat-card .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        .badge-notification {
            position: absolute;
            top: 5px;
            right: 5px;
            font-size: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <div class="col-md-2 admin-sidebar">
                <div class="p-3 text-center border-bottom border-secondary">
                    <img src="../images/logo.png" alt="HRMS" height="40" class="mb-2">
                    <h5 class="text-white mb-0">HRMS Admin</h5>
                </div>
                <nav class="nav flex-column mt-3">
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" href="index.php">
                        <i class="bi bi-speedometer2 me-2"></i>Dashboard
                    </a>
                    <a class="nav-link position-relative <?php echo basename($_SERVER['PHP_SELF']) == 'leave.php' ? 'active' : ''; ?>" href="leave.php">
                        <i class="bi bi-calendar-check me-2"></i>Kelola Cuti
                        <?php if ($pendingLeave > 0): ?>
                            <span class="badge bg-danger badge-notification"><?php echo $pendingLeave; ?></span>
                        <?php endif; ?>
                    </a>
                    <a class="nav-link position-relative <?php echo basename($_SERVER['PHP_SELF']) == 'overtime.php' ? 'active' : ''; ?>" href="overtime.php">
                        <i class="bi bi-clock-history me-2"></i>Kelola Lembur
                        <?php if ($pendingOvertime > 0): ?>
                            <span class="badge bg-danger badge-notification"><?php echo $pendingOvertime; ?></span>
                        <?php endif; ?>
                    </a>
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'payslip.php' ? 'active' : ''; ?>" href="payslip.php">
                        <i class="bi bi-receipt me-2"></i>Kelola Slip Gaji
                    </a>
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'inbox.php' ? 'active' : ''; ?>" href="inbox.php">
                        <i class="bi bi-envelope me-2"></i>Kirim Pesan
                    </a>
                    <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'employees.php' ? 'active' : ''; ?>" href="employees.php">
                        <i class="bi bi-people me-2"></i>Data Karyawan
                    </a>
                    <hr class="border-secondary mx-3">
                    <a class="nav-link text-danger" href="../logout.php">
                        <i class="bi bi-box-arrow-left me-2"></i>Logout
                    </a>
                </nav>
            </div>
            <div class="col-md-10 admin-content">
                <div class="admin-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><?php echo $pageTitle ?? 'Dashboard'; ?></h4>
                    <div class="d-flex align-items-center">
                        <span class="me-3">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Administrator'); ?>
                        </span>
                        <span class="badge bg-primary">Admin</span>
                    </div>
                </div>
                <div class="p-4">
