<?php
$pageTitle = 'Kelola Slip Gaji';
require_once 'includes/header.php';

$success = '';
$error = '';

$employees = $conn->query("SELECT id, full_name, department, position, salary FROM users WHERE role = 'employee' OR role IS NULL ORDER BY full_name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'generate') {
        $employeeId = intval($_POST['employee_id']);
        $periodMonth = intval($_POST['period_month']);
        $periodYear = intval($_POST['period_year']);
        $basicSalary = floatval($_POST['basic_salary']);
        $overtimePay = floatval($_POST['overtime_pay'] ?? 0);
        $allowances = floatval($_POST['allowances'] ?? 0);
        $deductions = floatval($_POST['deductions'] ?? 0);
        $tax = floatval($_POST['tax'] ?? 0);
        $netSalary = $basicSalary + $overtimePay + $allowances - $deductions - $tax;
        
        try {
            $check = $conn->prepare("SELECT id FROM payslips WHERE employee_id = :emp AND period_month = :month AND period_year = :year");
            $check->execute([':emp' => $employeeId, ':month' => $periodMonth, ':year' => $periodYear]);
            
            if ($check->rowCount() > 0) {
                $stmt = $conn->prepare("UPDATE payslips SET basic_salary = :basic, overtime_pay = :ot, allowances = :allow, deductions = :ded, tax = :tax, net_salary = :net, status = 'generated' WHERE employee_id = :emp AND period_month = :month AND period_year = :year");
            } else {
                $stmt = $conn->prepare("INSERT INTO payslips (employee_id, period_month, period_year, basic_salary, overtime_pay, allowances, deductions, tax, net_salary, status) VALUES (:emp, :month, :year, :basic, :ot, :allow, :ded, :tax, :net, 'generated')");
            }
            
            $stmt->execute([
                ':emp' => $employeeId,
                ':month' => $periodMonth,
                ':year' => $periodYear,
                ':basic' => $basicSalary,
                ':ot' => $overtimePay,
                ':allow' => $allowances,
                ':ded' => $deductions,
                ':tax' => $tax,
                ':net' => $netSalary
            ]);
            
            $success = 'Slip gaji berhasil dibuat!';
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    } elseif ($action === 'send') {
        $payslipId = intval($_POST['payslip_id']);
        
        try {
            $stmt = $conn->prepare("UPDATE payslips SET status = 'paid', payment_date = CURRENT_DATE WHERE id = :id");
            $stmt->execute([':id' => $payslipId]);
            
            $payslipData = $conn->prepare("SELECT p.*, u.full_name FROM payslips p JOIN users u ON p.employee_id = u.id WHERE p.id = :id");
            $payslipData->execute([':id' => $payslipId]);
            $payslip = $payslipData->fetch();
            
            $months = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
            $periodName = $months[$payslip['period_month']] . ' ' . $payslip['period_year'];
            
            $insertMsg = $conn->prepare("INSERT INTO inbox (recipient_id, sender_id, sender_name, subject, message, message_type, is_important) VALUES (:recipient, :sender, 'HR Admin', :subject, :message, 'info', 1)");
            $insertMsg->execute([
                ':recipient' => $payslip['employee_id'],
                ':sender' => $_SESSION['user_id'],
                ':subject' => 'Slip Gaji ' . $periodName . ' Tersedia',
                ':message' => "Slip gaji Anda untuk periode $periodName telah tersedia. Gaji bersih: Rp " . number_format($payslip['net_salary'], 0, ',', '.') . ". Silakan cek menu Slip Gaji untuk detail."
            ]);
            
            $success = 'Slip gaji berhasil dikirim dan notifikasi terkirim ke karyawan!';
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

$currentMonth = date('n');
$currentYear = date('Y');

$payslips = $conn->query("
    SELECT p.*, u.full_name, u.department 
    FROM payslips p 
    JOIN users u ON p.employee_id = u.id 
    ORDER BY p.period_year DESC, p.period_month DESC, u.full_name
    LIMIT 50
")->fetchAll();

$months = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
?>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i>Buat Slip Gaji</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="generate">
                    
                    <div class="mb-3">
                        <label class="form-label">Karyawan</label>
                        <select name="employee_id" class="form-select" required id="employeeSelect">
                            <option value="">Pilih Karyawan</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?php echo $emp['id']; ?>" data-salary="<?php echo $emp['salary']; ?>">
                                    <?php echo htmlspecialchars($emp['full_name']); ?> - <?php echo htmlspecialchars($emp['department']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="form-label">Bulan</label>
                            <select name="period_month" class="form-select" required>
                                <?php for ($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $i == $currentMonth ? 'selected' : ''; ?>><?php echo $months[$i]; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Tahun</label>
                            <select name="period_year" class="form-select" required>
                                <?php for ($y = $currentYear; $y >= $currentYear - 2; $y--): ?>
                                    <option value="<?php echo $y; ?>" <?php echo $y == $currentYear ? 'selected' : ''; ?>><?php echo $y; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Gaji Pokok (Rp)</label>
                        <input type="number" name="basic_salary" class="form-control" id="basicSalary" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Lembur (Rp)</label>
                        <input type="number" name="overtime_pay" class="form-control" value="0">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tunjangan (Rp)</label>
                        <input type="number" name="allowances" class="form-control" value="0">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Potongan (Rp)</label>
                        <input type="number" name="deductions" class="form-control" value="0">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Pajak (Rp)</label>
                        <input type="number" name="tax" class="form-control" value="0">
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-check-circle me-2"></i>Buat Slip Gaji
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-list-ul me-2"></i>Daftar Slip Gaji</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($payslips)): ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                        <p class="mt-3">Belum ada slip gaji</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Karyawan</th>
                                    <th>Periode</th>
                                    <th>Gaji Bersih</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payslips as $ps): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($ps['full_name']); ?></strong>
                                            <br><small class="text-muted"><?php echo htmlspecialchars($ps['department']); ?></small>
                                        </td>
                                        <td><?php echo $months[$ps['period_month']]; ?> <?php echo $ps['period_year']; ?></td>
                                        <td><strong>Rp <?php echo number_format($ps['net_salary'], 0, ',', '.'); ?></strong></td>
                                        <td>
                                            <?php
                                            $badgeClass = match($ps['status']) {
                                                'paid' => 'bg-success',
                                                'generated' => 'bg-info',
                                                default => 'bg-secondary'
                                            };
                                            $statusText = match($ps['status']) {
                                                'paid' => 'Terkirim',
                                                'generated' => 'Dibuat',
                                                default => 'Draft'
                                            };
                                            ?>
                                            <span class="badge <?php echo $badgeClass; ?>"><?php echo $statusText; ?></span>
                                        </td>
                                        <td>
                                            <?php if ($ps['status'] !== 'paid'): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="send">
                                                    <input type="hidden" name="payslip_id" value="<?php echo $ps['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Kirim slip gaji ini ke karyawan?')">
                                                        <i class="bi bi-send"></i> Kirim
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-success"><i class="bi bi-check-circle"></i> Terkirim</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('employeeSelect').addEventListener('change', function() {
    const selected = this.options[this.selectedIndex];
    const salary = selected.dataset.salary || 0;
    document.getElementById('basicSalary').value = salary;
});
</script>

<?php require_once 'includes/footer.php'; ?>
