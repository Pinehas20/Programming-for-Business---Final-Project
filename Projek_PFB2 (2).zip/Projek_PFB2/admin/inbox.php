<?php
$pageTitle = 'Kirim Pesan';
require_once 'includes/header.php';

$success = '';
$error = '';

$employees = $conn->query("SELECT id, full_name, department FROM users WHERE role = 'employee' OR role IS NULL ORDER BY full_name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipients = $_POST['recipients'] ?? [];
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $messageType = $_POST['message_type'] ?? 'info';
    $isImportant = isset($_POST['is_important']) ? 1 : 0;
    $sendToAll = isset($_POST['send_to_all']);
    
    if (empty($subject) || empty($message)) {
        $error = 'Subject dan pesan harus diisi!';
    } elseif (!$sendToAll && empty($recipients)) {
        $error = 'Pilih minimal satu penerima atau centang "Kirim ke Semua"!';
    } else {
        try {
            if ($sendToAll) {
                $recipients = array_column($employees, 'id');
            }
            
            $stmt = $conn->prepare("INSERT INTO inbox (recipient_id, sender_id, sender_name, subject, message, message_type, is_important) VALUES (:recipient, :sender, :sender_name, :subject, :message, :type, :important)");
            
            $count = 0;
            foreach ($recipients as $recipientId) {
                $stmt->execute([
                    ':recipient' => $recipientId,
                    ':sender' => $_SESSION['user_id'],
                    ':sender_name' => $_SESSION['full_name'],
                    ':subject' => $subject,
                    ':message' => $message,
                    ':type' => $messageType,
                    ':important' => $isImportant
                ]);
                $count++;
            }
            
            $success = "Pesan berhasil dikirim ke $count karyawan!";
        } catch (PDOException $e) {
            $error = 'Terjadi kesalahan: ' . $e->getMessage();
        }
    }
}

$sentMessages = $conn->query("
    SELECT i.*, u.full_name as recipient_name 
    FROM inbox i 
    JOIN users u ON i.recipient_id = u.id 
    WHERE i.sender_id = " . intval($_SESSION['user_id']) . "
    ORDER BY i.created_at DESC 
    LIMIT 50
")->fetchAll();
?>

<?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-pencil-square me-2"></i>Tulis Pesan Baru</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Penerima</label>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="send_to_all" id="sendToAll">
                            <label class="form-check-label" for="sendToAll">
                                <strong>Kirim ke Semua Karyawan</strong>
                            </label>
                        </div>
                        <select name="recipients[]" class="form-select" multiple size="5" id="recipientSelect">
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?php echo $emp['id']; ?>">
                                    <?php echo htmlspecialchars($emp['full_name']); ?> (<?php echo htmlspecialchars($emp['department']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Tahan Ctrl untuk memilih beberapa penerima</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tipe Pesan</label>
                        <select name="message_type" class="form-select">
                            <option value="info">Informasi</option>
                            <option value="announcement">Pengumuman</option>
                            <option value="warning">Peringatan</option>
                            <option value="personal">Personal</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <input type="text" name="subject" class="form-control" required placeholder="Masukkan subject pesan">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Pesan</label>
                        <textarea name="message" class="form-control" rows="5" required placeholder="Tulis pesan Anda di sini..."></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_important" id="isImportant">
                            <label class="form-check-label" for="isImportant">
                                <i class="bi bi-star-fill text-warning"></i> Tandai sebagai penting
                            </label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-send me-2"></i>Kirim Pesan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-7">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Pesan Terkirim</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($sentMessages)): ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                        <p class="mt-3">Belum ada pesan terkirim</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($sentMessages as $msg): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <div class="d-flex align-items-center mb-1">
                                            <?php if ($msg['is_important']): ?>
                                                <i class="bi bi-star-fill text-warning me-2"></i>
                                            <?php endif; ?>
                                            <strong><?php echo htmlspecialchars($msg['subject']); ?></strong>
                                            <?php
                                            $typeBadge = match($msg['message_type']) {
                                                'announcement' => 'bg-primary',
                                                'warning' => 'bg-warning',
                                                'personal' => 'bg-secondary',
                                                default => 'bg-info'
                                            };
                                            ?>
                                            <span class="badge <?php echo $typeBadge; ?> ms-2"><?php echo ucfirst($msg['message_type']); ?></span>
                                        </div>
                                        <p class="mb-1 text-muted small"><?php echo htmlspecialchars(substr($msg['message'], 0, 100)); ?><?php echo strlen($msg['message']) > 100 ? '...' : ''; ?></p>
                                        <small class="text-muted">
                                            <i class="bi bi-person me-1"></i><?php echo htmlspecialchars($msg['recipient_name']); ?>
                                            <span class="mx-2">|</span>
                                            <i class="bi bi-clock me-1"></i><?php echo date('d/m/Y H:i', strtotime($msg['created_at'])); ?>
                                            <?php if ($msg['is_read']): ?>
                                                <span class="mx-2">|</span>
                                                <span class="text-success"><i class="bi bi-check2-all"></i> Dibaca</span>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('sendToAll').addEventListener('change', function() {
    document.getElementById('recipientSelect').disabled = this.checked;
});
</script>

<?php require_once 'includes/footer.php'; ?>
