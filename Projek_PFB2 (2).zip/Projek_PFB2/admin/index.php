<?php
$pageTitle = 'Dashboard';
require_once 'includes/header.php';

$stats = [
    'employees' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'employee' OR role IS NULL")->fetch()['count'],
    'pendingLeave' => $conn->query("SELECT COUNT(*) as count FROM leave_requests WHERE status = 'pending'")->fetch()['count'],
    'pendingOvertime' => $conn->query("SELECT COUNT(*) as count FROM overtime WHERE status = 'pending'")->fetch()['count'],
    'todayAttendance' => $conn->query("SELECT COUNT(*) as count FROM attendance WHERE date = CURRENT_DATE")->fetch()['count']
];

$recentLeave = $conn->query("
    SELECT lr.*, u.full_name, u.department 
    FROM leave_requests lr 
    JOIN users u ON lr.employee_id = u.id 
    WHERE lr.status = 'pending' 
    ORDER BY lr.created_at DESC 
    LIMIT 5
")->fetchAll();

$recentOvertime = $conn->query("
    SELECT o.*, u.full_name, u.department 
    FROM overtime o 
    JOIN users u ON o.employee_id = u.id 
    WHERE o.status = 'pending' 
    ORDER BY o.created_at DESC 
    LIMIT 5
")->fetchAll();
?>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-primary text-white me-3">
                    <i class="bi bi-people"></i>
                </div>
                <div>
                    <h3 class="mb-0"><?php echo $stats['employees']; ?></h3>
                    <small class="text-muted">Total Karyawan</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-warning text-white me-3">
                    <i class="bi bi-calendar-check"></i>
                </div>
                <div>
                    <h3 class="mb-0"><?php echo $stats['pendingLeave']; ?></h3>
                    <small class="text-muted">Pengajuan Cuti</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-info text-white me-3">
                    <i class="bi bi-clock-history"></i>
                </div>
                <div>
                    <h3 class="mb-0"><?php echo $stats['pendingOvertime']; ?></h3>
                    <small class="text-muted">Pengajuan Lembur</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-success text-white me-3">
                    <i class="bi bi-check-circle"></i>
                </div>
                <div>
                    <h3 class="mb-0"><?php echo $stats['todayAttendance']; ?></h3>
                    <small class="text-muted">Hadir Hari Ini</small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-calendar-check me-2"></i>Pengajuan Cuti Terbaru</h5>
                <a href="leave.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recentLeave)): ?>
                    <div class="text-center py-4 text-muted">
                        <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                        <p class="mt-2 mb-0">Tidak ada pengajuan cuti pending</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Karyawan</th>
                                    <th>Tipe</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentLeave as $leave): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($leave['full_name']); ?></strong>
                                            <br><small class="text-muted"><?php echo htmlspecialchars($leave['department']); ?></small>
                                        </td>
                                        <td><?php echo ucfirst($leave['leave_type']); ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($leave['start_date'])); ?></td>
                                        <td>
                                            <a href="leave.php?action=view&id=<?php echo $leave['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Pengajuan Lembur Terbaru</h5>
                <a href="overtime.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($recentOvertime)): ?>
                    <div class="text-center py-4 text-muted">
                        <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                        <p class="mt-2 mb-0">Tidak ada pengajuan lembur pending</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Karyawan</th>
                                    <th>Tanggal</th>
                                    <th>Durasi</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentOvertime as $ot): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($ot['full_name']); ?></strong>
                                            <br><small class="text-muted"><?php echo htmlspecialchars($ot['department']); ?></small>
                                        </td>
                                        <td><?php echo date('d/m/Y', strtotime($ot['date'])); ?></td>
                                        <td><?php echo $ot['duration']; ?> jam</td>
                                        <td>
                                            <a href="overtime.php?action=view&id=<?php echo $ot['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
