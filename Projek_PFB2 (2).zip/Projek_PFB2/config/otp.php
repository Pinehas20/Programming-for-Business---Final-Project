<?php
/**
 * OTP Configuration
 */

return [
    'length' => 6,           // Panjang OTP (6 digit)
    'expiry' => 30,          // Kedaluwarsa dalam menit
    'max_attempts' => 5,     // Maksimal percobaan salah
    'resend_cooldown' => 60  // Cooldown resend dalam detik
];
