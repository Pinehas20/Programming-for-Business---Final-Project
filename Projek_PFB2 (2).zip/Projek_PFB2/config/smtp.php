<?php

return [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => 'hrmscodeid@gmail.com',
    'password' => 'eyvg jbeu haaf azeq', 
    'from_email' => 'hrmscodeid@gmail.com',
    'from_name' => 'HRMS System',
    'encryption' => 'tls',
    'debug' => 0 
];
